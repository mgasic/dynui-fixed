# Component Batches

## PILOT – Faza B
- DynChart

## Batch 1
- DynAvatar
- DynBadge
- DynBox
- DynBreadcrumb
- DynButton

## Batch 2
- DynCheckbox
- DynContainer
- DynDatePicker
- DynDivider
- DynFieldContainer

## Batch 3
- DynGauge
- DynGrid
- DynIcon
- DynInput
- DynLabel

## Batch 4
- DynListView
- DynMenu
- DynPage
- DynSelect
- DynStepper

## Batch 5
- DynTable
- DynTabs
- DynToolbar
- DynTreeView
- ThemeSwitcher
