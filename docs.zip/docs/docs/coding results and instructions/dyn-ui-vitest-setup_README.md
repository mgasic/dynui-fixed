# dyn-ui — Vitest Setup Kit

See vitest.config.ts, vitest.setup.ts, env.d.ts, scripts & patches inside.
