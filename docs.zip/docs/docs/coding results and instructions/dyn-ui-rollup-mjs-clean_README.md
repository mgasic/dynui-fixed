# DYN UI Monorepo

## Build

Svaki paket koristi Rollup konfiguraciju preko `rollup.config.mjs`.

### Komande

```bash
pnpm install
pnpm build
pnpm test
```

- `pnpm build` pokreće rollup build za sve pakete
- `pnpm test` pokreće Vitest testove
