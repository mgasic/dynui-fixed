# Dyn UI — Parallelization Lanes

## Lane-1: Foundations (A, H)
- A: Auto-discovery (roster/batches) — odmah, read-only.
- H: CI/Gates — skripte, pipeline, PR template.

## Lane-2: Pilot (B)
- DynChart standardizacija; referenca.

## Lane-3: Codemod (C)
- Normalizacija `index.ts`; merge posle B/H.

## Lane-4: Batches (D–G)
- Batch-1 posle B/H; Batch-2 kada je Batch-1 u review-u.
- Max 2 batch-a paralelno (3–5 komponenti po batch-u).

## Lane-5: Docs & Storybook
- Kontinuirano doterivanje dok batch-evi napreduju.

## Milestones
- M1: CI/Gates
- M2: Pilot
- M3: Codemod
- M4+: Batch-ovi
- Mfinal: Release + tag