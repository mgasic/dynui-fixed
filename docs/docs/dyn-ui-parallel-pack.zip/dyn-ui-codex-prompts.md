# Dyn UI — Codex Prompt Pack (Plan only)

## A) Auto-discovery
Plan only: prikaži rezultate i čekaj potvrdu. Ne menjaj kod.
Repo: mgasic/dyn-ui
Grana (opciono): chore/components-discovery
Zadatak: roster.md/csv i batches.md (A→Z, size=5; DynChart pilot).

## B) Pilot DynChart
Plan only: detaljan plan, zatim potvrda.
Repo: mgasic/dyn-ui; Grana: feat/dynchart-standards

## C) Codemod exports
Plan only: lista kandidata + diff šablon; potvrda pre primene.
Repo: mgasic/dyn-ui; Grana: chore/standard-exports

## D) Batch-N
Plan only: plan po komponenti (tabela/čeklista); potvrda.
Repo: mgasic/dyn-ui; Grana: feat/components-standards-[batch-id]

## H) CI/Gates
Plan only: dodaj skripte i pipeline (lint, test, storybook, gate).
Repo: mgasic/dyn-ui; Grana: chore/ci-gates