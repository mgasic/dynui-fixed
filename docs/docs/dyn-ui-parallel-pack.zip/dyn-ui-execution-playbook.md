# Dyn UI — Execution Playbook (Parallel Plan)

## Šta pokrenuti ODMAH (3 paralelna plana u Codex-u)

1) **Faza A — Auto-discovery (read-only + generisanje roster/batches)**
   - Plan only → prikaži `roster.md/csv` i `batches.md` (A→Z, size=5, bez DynChart).
   - Ne menja kod; može ići paralelno sa ostalim.

2) **Faza B — PILOT: DynChart (feat/dynchart-standards)**
   - Detaljan plan → implementacija → PR.
   - Rizik nizak (izolovana komponenta).

3) **Faza H — CI/Gate setup (chore/ci-gates)**
   - Dodaj skripte (`discover-components.js`, `gen-batches.js`, `gate-verify-components.js`), ESLint/tsconfig izvod, PR template.
   - Uvedi CI jobove: lint → test → storybook build → gate verifikacije.

> Očekivana korist: roster/batches definisani; pilot validira standard; CI/gate hvata regresije.

---

## Sledeći talas (paralelno)

4) **Faza C — Globalni codemod: index.ts export pattern (chore/standard-exports)**
   - Priprema paralelno dok traje pilot; **merge** posle aktivnog CI.
   - *Merge red:* CI/Gates → Pilot → **Codemod** → Batch-ovi.

5) **Faze D–G — Batch-ovi komponenti (feat/components-standards-batch-N)**
   - Batch-1 start čim Pilot ✅ i CI/Gates aktivni.
   - Batch-2 počni kada je Batch-1 u review-u (max 2 batch-a paralelno).
   - Svaki batch = 3–5 komponenti; izolovan PR.

6) **Dokumentacija & Storybook polishing (chore/docs-storybook)** — kontinuirano.