# Dyn UI — CI Gates & QA

## Pipeline
1) lint (ESLint + TS strict)
2) test (Vitest) — minimalna pokrivenost (npr. 80%)
3) storybook:build — bez grešaka
4) gate-verify — struktura i export pattern

## Gate skripta (sažetak)
- Za svaku komponentu: `.tsx`, `.stories.tsx`, `.test.tsx`, `index.ts`, i bar jedan `.module.css`.
- `index.ts` prati export pattern.
- (Opc.) heuristika da `Props` proširuju `BaseComponentProps`.

## Status checks (pre-merge)
- lint ✓  test ✓  storybook ✓  gate-verify ✓

## Code owners / Review
- ≥1 UI owner + ≥1 inženjer (rotate). Vizuelna verifikacija u Storybook-u.