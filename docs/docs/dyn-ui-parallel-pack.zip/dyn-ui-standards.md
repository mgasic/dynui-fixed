# Dyn UI — Standards (TS, Styling, Testing, Storybook, Exports)

## TS-first & Props
- Props **proširuju `BaseComponentProps`** (`id`, `className`, `data-testid`, `children`).
- Default props eksplicitni.
- Type-only export iz `index.ts` (`export type { XProps } from './X.types'`).

## Styling (CSS Modules)
- `.module.css`, prefiks `dyn-` + BEM varijante.
- Dinamičko kombinovanje: bazne + varijantne + `className`.

## Testing (Vitest + RTL)
- Render, interakcije, defaulti, edge, a11y osnove; snapshot minimalno.
- Pokrivenost ≥ postojeća; cilj ≥ 80% u CI.

## Storybook
- Controls za propove; varijante; kompozitni primeri; a11y napomene.

## Export pattern
```ts
export { [ComponentName] } from './[ComponentName]';
export { default } from './[ComponentName]';
export type { [ComponentName]Props } from './[ComponentName].types';
```